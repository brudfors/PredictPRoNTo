%-----------------------------------------------------------------------
% Job saved on 29-Nov-2018 14:11:34 by cfg_util (rev $Rev: 7345 $)
% cfg_basicio BasicIO - Unknown
% prt PRoNTo - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.cfg_basicio.var_ops.load_vars.matname = '<UNDEFINED>';
matlabbatch{1}.cfg_basicio.var_ops.load_vars.loadvars.varname = {'rt'};
matlabbatch{2}.cfg_basicio.var_ops.load_vars.matname = '<UNDEFINED>';
matlabbatch{2}.cfg_basicio.var_ops.load_vars.loadvars.varname = {'rt'};
matlabbatch{3}.cfg_basicio.var_ops.load_vars.matname = '<UNDEFINED>';
matlabbatch{3}.cfg_basicio.var_ops.load_vars.loadvars.varname = {'rt'};
matlabbatch{4}.cfg_basicio.file_dir.file_ops.cfg_named_file.name = 'images_g1m1_g1m2_g2m1_g2m2_g3m1_g3m2';
matlabbatch{4}.cfg_basicio.file_dir.file_ops.cfg_named_file.files = {
                                                                     '<UNDEFINED>'
                                                                     '<UNDEFINED>'
                                                                     '<UNDEFINED>'
                                                                     '<UNDEFINED>'
                                                                     '<UNDEFINED>'
                                                                     '<UNDEFINED>'
                                                                     }';
matlabbatch{5}.cfg_basicio.file_dir.file_ops.cfg_named_file.name = 'masks_m1_m2_atlas';
matlabbatch{5}.cfg_basicio.file_dir.file_ops.cfg_named_file.files = {
                                                                     '<UNDEFINED>'
                                                                     '<UNDEFINED>'
                                                                     '<UNDEFINED>'
                                                                     }';
matlabbatch{6}.cfg_basicio.file_dir.dir_ops.cfg_named_dir.name = 'top_resdir';
matlabbatch{6}.cfg_basicio.file_dir.dir_ops.cfg_named_dir.dirs = {'<UNDEFINED>'};
matlabbatch{7}.cfg_basicio.file_dir.dir_ops.cfg_mkdir.parent(1) = cfg_dep('Named Directory Selector: top_resdir(1)', substruct('.','val', '{}',{6}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','dirs', '{}',{1}));
matlabbatch{7}.cfg_basicio.file_dir.dir_ops.cfg_mkdir.name = 'test_results';
matlabbatch{8}.prt.data.dir_name(1) = cfg_dep('Make Directory: Make Directory ''test_results''', substruct('.','val', '{}',{7}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','dir'));
matlabbatch{8}.prt.data.group(1).gr_name = 'Guys';
matlabbatch{8}.prt.data.group(1).select.modality(1).mod_name = 'divergence';
matlabbatch{8}.prt.data.group(1).select.modality(1).subjects(1) = cfg_dep('Named File Selector: images_g1m1_g1m2_g2m1_g2m2_g3m1_g3m2(1) - Files', substruct('.','val', '{}',{4}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{1}));
matlabbatch{8}.prt.data.group(1).select.modality(1).rt_subj(1) = cfg_dep('Load Variables from .mat File: Loaded Variable ''rt''', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('{}',{1}));
matlabbatch{8}.prt.data.group(1).select.modality(1).covar = {''};
matlabbatch{8}.prt.data.group(1).select.modality(2).mod_name = 'momentum';
matlabbatch{8}.prt.data.group(1).select.modality(2).subjects(1) = cfg_dep('Named File Selector: images_g1m1_g1m2_g2m1_g2m2_g3m1_g3m2(2) - Files', substruct('.','val', '{}',{4}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{2}));
matlabbatch{8}.prt.data.group(1).select.modality(2).rt_subj(1) = cfg_dep('Load Variables from .mat File: Loaded Variable ''rt''', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('{}',{1}));
matlabbatch{8}.prt.data.group(1).select.modality(2).covar = {''};
matlabbatch{8}.prt.data.group(2).gr_name = 'HammersH';
matlabbatch{8}.prt.data.group(2).select.modality(1).mod_name = 'divergence';
matlabbatch{8}.prt.data.group(2).select.modality(1).subjects(1) = cfg_dep('Named File Selector: images_g1m1_g1m2_g2m1_g2m2_g3m1_g3m2(3) - Files', substruct('.','val', '{}',{4}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{3}));
matlabbatch{8}.prt.data.group(2).select.modality(1).rt_subj(1) = cfg_dep('Load Variables from .mat File: Loaded Variable ''rt''', substruct('.','val', '{}',{2}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('{}',{1}));
matlabbatch{8}.prt.data.group(2).select.modality(1).covar = {''};
matlabbatch{8}.prt.data.group(2).select.modality(2).mod_name = 'momentum';
matlabbatch{8}.prt.data.group(2).select.modality(2).subjects(1) = cfg_dep('Named File Selector: images_g1m1_g1m2_g2m1_g2m2_g3m1_g3m2(4) - Files', substruct('.','val', '{}',{4}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{4}));
matlabbatch{8}.prt.data.group(2).select.modality(2).rt_subj(1) = cfg_dep('Load Variables from .mat File: Loaded Variable ''rt''', substruct('.','val', '{}',{2}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('{}',{1}));
matlabbatch{8}.prt.data.group(2).select.modality(2).covar = {''};
matlabbatch{8}.prt.data.group(3).gr_name = 'IOP';
matlabbatch{8}.prt.data.group(3).select.modality(1).mod_name = 'divergence';
matlabbatch{8}.prt.data.group(3).select.modality(1).subjects(1) = cfg_dep('Named File Selector: images_g1m1_g1m2_g2m1_g2m2_g3m1_g3m2(5) - Files', substruct('.','val', '{}',{4}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{5}));
matlabbatch{8}.prt.data.group(3).select.modality(1).rt_subj(1) = cfg_dep('Load Variables from .mat File: Loaded Variable ''rt''', substruct('.','val', '{}',{3}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('{}',{1}));
matlabbatch{8}.prt.data.group(3).select.modality(1).covar = {''};
matlabbatch{8}.prt.data.group(3).select.modality(2).mod_name = 'momentum';
matlabbatch{8}.prt.data.group(3).select.modality(2).subjects(1) = cfg_dep('Named File Selector: images_g1m1_g1m2_g2m1_g2m2_g3m1_g3m2(6) - Files', substruct('.','val', '{}',{4}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{6}));
matlabbatch{8}.prt.data.group(3).select.modality(2).rt_subj(1) = cfg_dep('Load Variables from .mat File: Loaded Variable ''rt''', substruct('.','val', '{}',{3}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('{}',{1}));
matlabbatch{8}.prt.data.group(3).select.modality(2).covar = {''};
matlabbatch{8}.prt.data.mask(1).mod_name = 'divergence';
matlabbatch{8}.prt.data.mask(1).fmask(1) = cfg_dep('Named File Selector: masks_m1_m2_atlas(1) - Files', substruct('.','val', '{}',{5}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{1}));
matlabbatch{8}.prt.data.mask(1).hrfover = 0;
matlabbatch{8}.prt.data.mask(1).hrfdel = 0;
matlabbatch{8}.prt.data.mask(2).mod_name = 'momentum';
matlabbatch{8}.prt.data.mask(2).fmask(1) = cfg_dep('Named File Selector: masks_m1_m2_atlas(2) - Files', substruct('.','val', '{}',{5}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{2}));
matlabbatch{8}.prt.data.mask(2).hrfover = 0;
matlabbatch{8}.prt.data.mask(2).hrfdel = 0;
matlabbatch{8}.prt.data.review = 0;
matlabbatch{9}.prt.fs.infile(1) = cfg_dep('Data & Design: PRT.mat file', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{9}.prt.fs.k_file = 'IXI_divergence';
matlabbatch{9}.prt.fs.modality.mod_name(1) = cfg_dep('Data & Design: Mod#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','mod_name1'));
matlabbatch{9}.prt.fs.modality.conditions.all_scans = 1;
matlabbatch{9}.prt.fs.modality.voxels.all_voxels = 1;
matlabbatch{9}.prt.fs.modality.detrend.no_dt = 1;
matlabbatch{9}.prt.fs.modality.normalise.no_gms = 1;
matlabbatch{9}.prt.fs.modality.atlasroi = {''};
matlabbatch{9}.prt.fs.flag_mm = 0;
matlabbatch{10}.prt.model.infile(1) = cfg_dep('Feature set/Kernel: PRT.mat file', substruct('.','val', '{}',{9}, '.','val', '{}',{1}), substruct('.','fname'));
matlabbatch{10}.prt.model.model_name = 'svm_guys_vs_hamiop';
matlabbatch{10}.prt.model.use_kernel = 1;
matlabbatch{10}.prt.model.fsets(1) = cfg_dep('Feature set/Kernel: Feature/kernel name', substruct('.','val', '{}',{9}, '.','val', '{}',{1}), substruct('.','fs_name'));
matlabbatch{10}.prt.model.model_type.classification.class(1).class_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{10}.prt.model.model_type.classification.class(1).group.gr_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{10}.prt.model.model_type.classification.class(1).group.subj_nums = [1
                                                                                2
                                                                                3
                                                                                4
                                                                                5];
matlabbatch{10}.prt.model.model_type.classification.class(1).group.conditions.all_scans = 1;
matlabbatch{10}.prt.model.model_type.classification.class(2).class_name = 'Hamm_IOP';
matlabbatch{10}.prt.model.model_type.classification.class(2).group(1).gr_name(1) = cfg_dep('Data & Design: Group#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name2'));
matlabbatch{10}.prt.model.model_type.classification.class(2).group(1).subj_nums = [1
                                                                                   2
                                                                                   3
                                                                                   4
                                                                                   5];
matlabbatch{10}.prt.model.model_type.classification.class(2).group(1).conditions.all_scans = 1;
matlabbatch{10}.prt.model.model_type.classification.class(2).group(2).gr_name(1) = cfg_dep('Data & Design: Group#3 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name3'));
matlabbatch{10}.prt.model.model_type.classification.class(2).group(2).subj_nums = [1
                                                                                   2
                                                                                   3
                                                                                   4
                                                                                   5];
matlabbatch{10}.prt.model.model_type.classification.class(2).group(2).conditions.all_scans = 1;
matlabbatch{10}.prt.model.model_type.classification.machine_cl.svm.svm_opt = 0;
matlabbatch{10}.prt.model.model_type.classification.machine_cl.svm.svm_args = '-s 0 -t 4 -c 1';
matlabbatch{10}.prt.model.model_type.classification.machine_cl.svm.cv_type_nested.cv_loso = 1;
matlabbatch{10}.prt.model.cv_type.cv_losgo = 1;
matlabbatch{10}.prt.model.include_allscans = 0;
matlabbatch{10}.prt.model.sel_ops.data_op_mc = 0;
matlabbatch{10}.prt.model.sel_ops.use_other_ops.no_op = 1;
matlabbatch{11}.prt.cv_model.infile(1) = cfg_dep('Specify model: PRT.mat file', substruct('.','val', '{}',{10}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{11}.prt.cv_model.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{10}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{11}.prt.cv_model.perm_test.perm_t.N_perm = 1000;
matlabbatch{11}.prt.cv_model.perm_test.perm_t.flag_sw = 0;
matlabbatch{12}.prt.weights.infile(1) = cfg_dep('Run model: PRT.mat file', substruct('.','val', '{}',{11}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{12}.prt.weights.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{10}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{12}.prt.weights.img_name = 'svm_GvsHI';
matlabbatch{12}.prt.weights.build_wpr.no_atl = 0;
matlabbatch{12}.prt.weights.flag_cwi = 0;
matlabbatch{13}.prt.fs.infile(1) = cfg_dep('Data & Design: PRT.mat file', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{13}.prt.fs.k_file = 'IXI_momentum';
matlabbatch{13}.prt.fs.modality.mod_name(1) = cfg_dep('Data & Design: Mod#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','mod_name2'));
matlabbatch{13}.prt.fs.modality.conditions.all_scans = 1;
matlabbatch{13}.prt.fs.modality.voxels.all_voxels = 1;
matlabbatch{13}.prt.fs.modality.detrend.no_dt = 1;
matlabbatch{13}.prt.fs.modality.normalise.no_gms = 1;
matlabbatch{13}.prt.fs.modality.atlasroi = {''};
matlabbatch{13}.prt.fs.flag_mm = 0;
matlabbatch{14}.prt.model.infile(1) = cfg_dep('Feature set/Kernel: PRT.mat file', substruct('.','val', '{}',{13}, '.','val', '{}',{1}), substruct('.','fname'));
matlabbatch{14}.prt.model.model_name = 'KRR_age_regress';
matlabbatch{14}.prt.model.use_kernel = 1;
matlabbatch{14}.prt.model.fsets(1) = cfg_dep('Feature set/Kernel: Feature/kernel name', substruct('.','val', '{}',{13}, '.','val', '{}',{1}), substruct('.','fs_name'));
matlabbatch{14}.prt.model.model_type.regression.reg_group(1).gr_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{14}.prt.model.model_type.regression.reg_group(1).subj_nums = [1
                                                                          2
                                                                          3
                                                                          4
                                                                          5];
matlabbatch{14}.prt.model.model_type.regression.reg_group(2).gr_name(1) = cfg_dep('Data & Design: Group#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name2'));
matlabbatch{14}.prt.model.model_type.regression.reg_group(2).subj_nums = [1
                                                                          2
                                                                          3
                                                                          4
                                                                          5];
matlabbatch{14}.prt.model.model_type.regression.reg_group(3).gr_name(1) = cfg_dep('Data & Design: Group#3 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name3'));
matlabbatch{14}.prt.model.model_type.regression.reg_group(3).subj_nums = [1
                                                                          2
                                                                          3
                                                                          4
                                                                          5];
matlabbatch{14}.prt.model.model_type.regression.machine_rg.krr.krr_opt = 0;
matlabbatch{14}.prt.model.model_type.regression.machine_rg.krr.krr_args = 1;
matlabbatch{14}.prt.model.model_type.regression.machine_rg.krr.cv_type_nested.cv_loso = 1;
matlabbatch{14}.prt.model.cv_type.cv_loso = 1;
matlabbatch{14}.prt.model.include_allscans = 0;
matlabbatch{14}.prt.model.sel_ops.data_op_mc = 0;
matlabbatch{14}.prt.model.sel_ops.use_other_ops.no_op = 1;
matlabbatch{15}.prt.cv_model.infile(1) = cfg_dep('Specify model: PRT.mat file', substruct('.','val', '{}',{14}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{15}.prt.cv_model.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{14}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{15}.prt.cv_model.perm_test.perm_t.N_perm = 1000;
matlabbatch{15}.prt.cv_model.perm_test.perm_t.flag_sw = 0;
matlabbatch{16}.prt.fs.infile(1) = cfg_dep('Data & Design: PRT.mat file', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{16}.prt.fs.k_file = 'IXI_mom_div';
matlabbatch{16}.prt.fs.modality(1).mod_name(1) = cfg_dep('Data & Design: Mod#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','mod_name1'));
matlabbatch{16}.prt.fs.modality(1).conditions.all_scans = 1;
matlabbatch{16}.prt.fs.modality(1).voxels.all_voxels = 1;
matlabbatch{16}.prt.fs.modality(1).detrend.no_dt = 1;
matlabbatch{16}.prt.fs.modality(1).normalise.no_gms = 1;
matlabbatch{16}.prt.fs.modality(1).atlasroi = {''};
matlabbatch{16}.prt.fs.modality(2).mod_name(1) = cfg_dep('Data & Design: Mod#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','mod_name2'));
matlabbatch{16}.prt.fs.modality(2).conditions.all_scans = 1;
matlabbatch{16}.prt.fs.modality(2).voxels.all_voxels = 1;
matlabbatch{16}.prt.fs.modality(2).detrend.no_dt = 1;
matlabbatch{16}.prt.fs.modality(2).normalise.no_gms = 1;
matlabbatch{16}.prt.fs.modality(2).atlasroi = {''};
matlabbatch{16}.prt.fs.flag_mm = 0;
matlabbatch{17}.prt.model.infile(1) = cfg_dep('Feature set/Kernel: PRT.mat file', substruct('.','val', '{}',{16}, '.','val', '{}',{1}), substruct('.','fname'));
matlabbatch{17}.prt.model.model_name = 'gpc_3centres_2mod';
matlabbatch{17}.prt.model.use_kernel = 1;
matlabbatch{17}.prt.model.fsets(1) = cfg_dep('Feature set/Kernel: Feature/kernel name', substruct('.','val', '{}',{16}, '.','val', '{}',{1}), substruct('.','fs_name'));
matlabbatch{17}.prt.model.model_type.classification.class(1).class_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{17}.prt.model.model_type.classification.class(1).group.gr_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{17}.prt.model.model_type.classification.class(1).group.subj_nums = [1
                                                                                2
                                                                                3
                                                                                4
                                                                                5];
matlabbatch{17}.prt.model.model_type.classification.class(1).group.conditions.all_scans = 1;
matlabbatch{17}.prt.model.model_type.classification.class(2).class_name(1) = cfg_dep('Data & Design: Group#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name2'));
matlabbatch{17}.prt.model.model_type.classification.class(2).group.gr_name(1) = cfg_dep('Data & Design: Group#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name2'));
matlabbatch{17}.prt.model.model_type.classification.class(2).group.subj_nums = [1
                                                                                2
                                                                                3
                                                                                4
                                                                                5];
matlabbatch{17}.prt.model.model_type.classification.class(2).group.conditions.all_scans = 1;
matlabbatch{17}.prt.model.model_type.classification.class(3).class_name(1) = cfg_dep('Data & Design: Group#3 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name3'));
matlabbatch{17}.prt.model.model_type.classification.class(3).group.gr_name(1) = cfg_dep('Data & Design: Group#3 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name3'));
matlabbatch{17}.prt.model.model_type.classification.class(3).group.subj_nums = [1
                                                                                2
                                                                                3
                                                                                4
                                                                                5];
matlabbatch{17}.prt.model.model_type.classification.class(3).group.conditions.all_scans = 1;
matlabbatch{17}.prt.model.model_type.classification.machine_cl.gpc.gpc_args = '-l erf -h';
matlabbatch{17}.prt.model.cv_type.cv_losgo = 1;
matlabbatch{17}.prt.model.include_allscans = 0;
matlabbatch{17}.prt.model.sel_ops.data_op_mc = 0;
matlabbatch{17}.prt.model.sel_ops.use_other_ops.no_op = 1;
matlabbatch{18}.prt.cv_model.infile(1) = cfg_dep('Specify model: PRT.mat file', substruct('.','val', '{}',{17}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{18}.prt.cv_model.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{17}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{18}.prt.cv_model.perm_test.no_perm = 1;
matlabbatch{19}.prt.weights.infile(1) = cfg_dep('Run model: PRT.mat file', substruct('.','val', '{}',{18}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{19}.prt.weights.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{17}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{19}.prt.weights.img_name = 'gpc_3C_2m';
matlabbatch{19}.prt.weights.build_wpr.no_atl = 0;
matlabbatch{19}.prt.weights.flag_cwi = 0;
matlabbatch{20}.prt.model.infile(1) = cfg_dep('Feature set/Kernel: PRT.mat file', substruct('.','val', '{}',{13}, '.','val', '{}',{1}), substruct('.','fname'));
matlabbatch{20}.prt.model.model_name = 'RVR_age_regress';
matlabbatch{20}.prt.model.use_kernel = 1;
matlabbatch{20}.prt.model.fsets(1) = cfg_dep('Feature set/Kernel: Feature/kernel name', substruct('.','val', '{}',{13}, '.','val', '{}',{1}), substruct('.','fs_name'));
matlabbatch{20}.prt.model.model_type.regression.reg_group(1).gr_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{20}.prt.model.model_type.regression.reg_group(1).subj_nums = [1
                                                                          2
                                                                          3
                                                                          4
                                                                          5];
matlabbatch{20}.prt.model.model_type.regression.reg_group(2).gr_name(1) = cfg_dep('Data & Design: Group#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name2'));
matlabbatch{20}.prt.model.model_type.regression.reg_group(2).subj_nums = [1
                                                                          2
                                                                          3
                                                                          4
                                                                          5];
matlabbatch{20}.prt.model.model_type.regression.reg_group(3).gr_name(1) = cfg_dep('Data & Design: Group#3 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name3'));
matlabbatch{20}.prt.model.model_type.regression.reg_group(3).subj_nums = [1
                                                                          2
                                                                          3
                                                                          4
                                                                          5];
matlabbatch{20}.prt.model.model_type.regression.machine_rg.rvr = struct([]);
matlabbatch{20}.prt.model.cv_type.cv_loso = 1;
matlabbatch{20}.prt.model.include_allscans = 0;
matlabbatch{20}.prt.model.sel_ops.data_op_mc = 0;
matlabbatch{20}.prt.model.sel_ops.use_other_ops.no_op = 1;
matlabbatch{21}.prt.cv_model.infile(1) = cfg_dep('Specify model: PRT.mat file', substruct('.','val', '{}',{20}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{21}.prt.cv_model.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{20}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{21}.prt.cv_model.perm_test.no_perm = 1;
matlabbatch{22}.prt.model.infile(1) = cfg_dep('Feature set/Kernel: PRT.mat file', substruct('.','val', '{}',{13}, '.','val', '{}',{1}), substruct('.','fname'));
matlabbatch{22}.prt.model.model_name = 'GPR_age_regress';
matlabbatch{22}.prt.model.use_kernel = 1;
matlabbatch{22}.prt.model.fsets(1) = cfg_dep('Feature set/Kernel: Feature/kernel name', substruct('.','val', '{}',{13}, '.','val', '{}',{1}), substruct('.','fs_name'));
matlabbatch{22}.prt.model.model_type.regression.reg_group(1).gr_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{22}.prt.model.model_type.regression.reg_group(1).subj_nums = [1
                                                                          2
                                                                          3
                                                                          4
                                                                          5];
matlabbatch{22}.prt.model.model_type.regression.reg_group(2).gr_name(1) = cfg_dep('Data & Design: Group#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name2'));
matlabbatch{22}.prt.model.model_type.regression.reg_group(2).subj_nums = [1
                                                                          2
                                                                          3
                                                                          4
                                                                          5];
matlabbatch{22}.prt.model.model_type.regression.reg_group(3).gr_name(1) = cfg_dep('Data & Design: Group#3 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name3'));
matlabbatch{22}.prt.model.model_type.regression.reg_group(3).subj_nums = [1
                                                                          2
                                                                          3
                                                                          4
                                                                          5];
matlabbatch{22}.prt.model.model_type.regression.machine_rg.gpr.gpr_args = '-l gauss -h';
matlabbatch{22}.prt.model.cv_type.cv_loso = 1;
matlabbatch{22}.prt.model.include_allscans = 0;
matlabbatch{22}.prt.model.sel_ops.data_op_mc = 0;
matlabbatch{22}.prt.model.sel_ops.use_other_ops.no_op = 1;
matlabbatch{23}.prt.cv_model.infile(1) = cfg_dep('Specify model: PRT.mat file', substruct('.','val', '{}',{22}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{23}.prt.cv_model.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{22}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{23}.prt.cv_model.perm_test.no_perm = 1;
matlabbatch{24}.prt.fs.infile(1) = cfg_dep('Data & Design: PRT.mat file', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{24}.prt.fs.k_file = 'IXI_DivMom_MMkernel';
matlabbatch{24}.prt.fs.modality(1).mod_name(1) = cfg_dep('Data & Design: Mod#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','mod_name1'));
matlabbatch{24}.prt.fs.modality(1).conditions.all_scans = 1;
matlabbatch{24}.prt.fs.modality(1).voxels.all_voxels = 1;
matlabbatch{24}.prt.fs.modality(1).detrend.no_dt = 1;
matlabbatch{24}.prt.fs.modality(1).normalise.no_gms = 1;
matlabbatch{24}.prt.fs.modality(1).atlasroi = {''};
matlabbatch{24}.prt.fs.modality(2).mod_name(1) = cfg_dep('Data & Design: Mod#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','mod_name2'));
matlabbatch{24}.prt.fs.modality(2).conditions.all_scans = 1;
matlabbatch{24}.prt.fs.modality(2).voxels.all_voxels = 1;
matlabbatch{24}.prt.fs.modality(2).detrend.no_dt = 1;
matlabbatch{24}.prt.fs.modality(2).normalise.no_gms = 1;
matlabbatch{24}.prt.fs.modality(2).atlasroi = {''};
matlabbatch{24}.prt.fs.flag_mm = 1;
matlabbatch{25}.prt.fs.infile(1) = cfg_dep('Data & Design: PRT.mat file', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{25}.prt.fs.k_file = 'IXI_DivMom_MMandROIkernel';
matlabbatch{25}.prt.fs.modality(1).mod_name(1) = cfg_dep('Data & Design: Mod#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','mod_name1'));
matlabbatch{25}.prt.fs.modality(1).conditions.all_scans = 1;
matlabbatch{25}.prt.fs.modality(1).voxels.all_voxels = 1;
matlabbatch{25}.prt.fs.modality(1).detrend.no_dt = 1;
matlabbatch{25}.prt.fs.modality(1).normalise.no_gms = 1;
matlabbatch{25}.prt.fs.modality(1).atlasroi(1) = cfg_dep('Named File Selector: masks_m1_m2_atlas(3) - Files', substruct('.','val', '{}',{5}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{3}));
matlabbatch{25}.prt.fs.modality(2).mod_name(1) = cfg_dep('Data & Design: Mod#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','mod_name2'));
matlabbatch{25}.prt.fs.modality(2).conditions.all_scans = 1;
matlabbatch{25}.prt.fs.modality(2).voxels.all_voxels = 1;
matlabbatch{25}.prt.fs.modality(2).detrend.no_dt = 1;
matlabbatch{25}.prt.fs.modality(2).normalise.no_gms = 1;
matlabbatch{25}.prt.fs.modality(2).atlasroi(1) = cfg_dep('Named File Selector: masks_m1_m2_atlas(3) - Files', substruct('.','val', '{}',{5}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{3}));
matlabbatch{25}.prt.fs.flag_mm = 1;
matlabbatch{26}.prt.model.infile(1) = cfg_dep('Feature set/Kernel: PRT.mat file', substruct('.','val', '{}',{9}, '.','val', '{}',{1}), substruct('.','fname'));
matlabbatch{26}.prt.model.model_name = 'MKLmm_guys_vs_hamiop';
matlabbatch{26}.prt.model.use_kernel = 1;
matlabbatch{26}.prt.model.fsets(1) = cfg_dep('Feature set/Kernel: Feature/kernel name', substruct('.','val', '{}',{24}, '.','val', '{}',{1}), substruct('.','fs_name'));
matlabbatch{26}.prt.model.model_type.classification.class(1).class_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{26}.prt.model.model_type.classification.class(1).group.gr_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{26}.prt.model.model_type.classification.class(1).group.subj_nums = [1
                                                                                2
                                                                                3
                                                                                4
                                                                                5];
matlabbatch{26}.prt.model.model_type.classification.class(1).group.conditions.all_scans = 1;
matlabbatch{26}.prt.model.model_type.classification.class(2).class_name = 'Hamm_IOP';
matlabbatch{26}.prt.model.model_type.classification.class(2).group(1).gr_name(1) = cfg_dep('Data & Design: Group#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name2'));
matlabbatch{26}.prt.model.model_type.classification.class(2).group(1).subj_nums = [1
                                                                                   2
                                                                                   3
                                                                                   4
                                                                                   5];
matlabbatch{26}.prt.model.model_type.classification.class(2).group(1).conditions.all_scans = 1;
matlabbatch{26}.prt.model.model_type.classification.class(2).group(2).gr_name(1) = cfg_dep('Data & Design: Group#3 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name3'));
matlabbatch{26}.prt.model.model_type.classification.class(2).group(2).subj_nums = [1
                                                                                   2
                                                                                   3
                                                                                   4
                                                                                   5];
matlabbatch{26}.prt.model.model_type.classification.class(2).group(2).conditions.all_scans = 1;
matlabbatch{26}.prt.model.model_type.classification.machine_cl.sMKL_cla.sMKL_cla_opt = 0;
matlabbatch{26}.prt.model.model_type.classification.machine_cl.sMKL_cla.sMKL_cla_args = 1;
matlabbatch{26}.prt.model.model_type.classification.machine_cl.sMKL_cla.cv_type_nested.cv_loso = 1;
matlabbatch{26}.prt.model.cv_type.cv_losgo = 1;
matlabbatch{26}.prt.model.include_allscans = 0;
matlabbatch{26}.prt.model.sel_ops.data_op_mc = 0;
matlabbatch{26}.prt.model.sel_ops.use_other_ops.no_op = 1;
matlabbatch{27}.prt.cv_model.infile(1) = cfg_dep('Specify model: PRT.mat file', substruct('.','val', '{}',{26}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{27}.prt.cv_model.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{26}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{27}.prt.cv_model.perm_test.no_perm = 1;
matlabbatch{28}.prt.weights.infile(1) = cfg_dep('Run model: PRT.mat file', substruct('.','val', '{}',{27}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{28}.prt.weights.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{26}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{28}.prt.weights.img_name = 'MKLmm_weights';
matlabbatch{28}.prt.weights.build_wpr.no_atl = 0;
matlabbatch{28}.prt.weights.flag_cwi = 0;
matlabbatch{29}.prt.model.infile(1) = cfg_dep('Feature set/Kernel: PRT.mat file', substruct('.','val', '{}',{9}, '.','val', '{}',{1}), substruct('.','fname'));
matlabbatch{29}.prt.model.model_name = 'MKLmmroi_guys_vs_hamiop';
matlabbatch{29}.prt.model.use_kernel = 1;
matlabbatch{29}.prt.model.fsets(1) = cfg_dep('Feature set/Kernel: Feature/kernel name', substruct('.','val', '{}',{24}, '.','val', '{}',{1}), substruct('.','fs_name'));
matlabbatch{29}.prt.model.model_type.classification.class(1).class_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{29}.prt.model.model_type.classification.class(1).group.gr_name(1) = cfg_dep('Data & Design: Group#1 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name1'));
matlabbatch{29}.prt.model.model_type.classification.class(1).group.subj_nums = [1
                                                                                2
                                                                                3
                                                                                4
                                                                                5];
matlabbatch{29}.prt.model.model_type.classification.class(1).group.conditions.all_scans = 1;
matlabbatch{29}.prt.model.model_type.classification.class(2).class_name = 'Hamm_IOP';
matlabbatch{29}.prt.model.model_type.classification.class(2).group(1).gr_name(1) = cfg_dep('Data & Design: Group#2 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name2'));
matlabbatch{29}.prt.model.model_type.classification.class(2).group(1).subj_nums = [1
                                                                                   2
                                                                                   3
                                                                                   4
                                                                                   5];
matlabbatch{29}.prt.model.model_type.classification.class(2).group(1).conditions.all_scans = 1;
matlabbatch{29}.prt.model.model_type.classification.class(2).group(2).gr_name(1) = cfg_dep('Data & Design: Group#3 name', substruct('.','val', '{}',{8}, '.','val', '{}',{1}), substruct('.','gr_name3'));
matlabbatch{29}.prt.model.model_type.classification.class(2).group(2).subj_nums = [1
                                                                                   2
                                                                                   3
                                                                                   4
                                                                                   5];
matlabbatch{29}.prt.model.model_type.classification.class(2).group(2).conditions.all_scans = 1;
matlabbatch{29}.prt.model.model_type.classification.machine_cl.sMKL_cla.sMKL_cla_opt = 0;
matlabbatch{29}.prt.model.model_type.classification.machine_cl.sMKL_cla.sMKL_cla_args = 1;
matlabbatch{29}.prt.model.model_type.classification.machine_cl.sMKL_cla.cv_type_nested.cv_loso = 1;
matlabbatch{29}.prt.model.cv_type.cv_losgo = 1;
matlabbatch{29}.prt.model.include_allscans = 0;
matlabbatch{29}.prt.model.sel_ops.data_op_mc = 0;
matlabbatch{29}.prt.model.sel_ops.use_other_ops.no_op = 1;
matlabbatch{30}.prt.cv_model.infile(1) = cfg_dep('Specify model: PRT.mat file', substruct('.','val', '{}',{29}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{30}.prt.cv_model.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{29}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{30}.prt.cv_model.perm_test.no_perm = 1;
matlabbatch{31}.prt.weights.infile(1) = cfg_dep('Run model: PRT.mat file', substruct('.','val', '{}',{30}, '.','val', '{}',{1}), substruct('.','files'));
matlabbatch{31}.prt.weights.model_name(1) = cfg_dep('Specify model: Model name', substruct('.','val', '{}',{29}, '.','val', '{}',{1}), substruct('.','mname'));
matlabbatch{31}.prt.weights.img_name = 'MKLmmroi_weights';
matlabbatch{31}.prt.weights.build_wpr.atl_name(1) = cfg_dep('Named File Selector: masks_m1_m2_atlas(3) - Files', substruct('.','val', '{}',{5}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','files', '{}',{3}));
matlabbatch{31}.prt.weights.flag_cwi = 0;
