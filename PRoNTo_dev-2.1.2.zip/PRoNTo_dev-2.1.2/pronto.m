function pronto
% Function launching PRoNTo (Pattern Recognition for Neuroimaging Toolbox),
% see prt.m for more details
%
%_______________________________________________________________________
% Copyright (C) 2012 Machine Learning & Neuroimaging Laboratory

% Written by Christophe Phillips
% $Id$

prt;
return