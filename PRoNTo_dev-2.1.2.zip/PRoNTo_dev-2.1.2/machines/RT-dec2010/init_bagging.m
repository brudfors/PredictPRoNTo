
function rtensparam=init_bagging()
  
  rtensparam.nbterms=100;
  rtensparam.bootstrap=1;
  rtparam.nmin=1;
  rtparam.varmin=0;
  rtparam.savepred=1;
  rtparam.bestfirst=0;
  rtparam.extratrees=0;

  rtparam.savepred=1;
  rtensparam.rtparam=rtparam;