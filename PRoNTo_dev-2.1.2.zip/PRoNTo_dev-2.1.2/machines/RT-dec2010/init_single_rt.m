
function rtensparam=init_single_rt()
  
  rtensparam.nbterms=1;
  rtensparam.bootstrap=0;
  rtparam.nmin=1;
  rtparam.varmin=0;
  rtparam.savepred=1;
  rtparam.bestfirst=0;
  rtparam.extratrees=0;

  rtensparam.rtparam=rtparam;